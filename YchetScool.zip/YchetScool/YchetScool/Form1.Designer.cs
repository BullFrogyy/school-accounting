﻿namespace YchetScool
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button1 = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label102 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.button19 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.button11 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.comboBox38 = new System.Windows.Forms.ComboBox();
            this.comboBox39 = new System.Windows.Forms.ComboBox();
            this.label111 = new System.Windows.Forms.Label();
            this.label112 = new System.Windows.Forms.Label();
            this.label113 = new System.Windows.Forms.Label();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.button4 = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.label122 = new System.Windows.Forms.Label();
            this.label123 = new System.Windows.Forms.Label();
            this.label124 = new System.Windows.Forms.Label();
            this.label125 = new System.Windows.Forms.Label();
            this.label126 = new System.Windows.Forms.Label();
            this.textBox70 = new System.Windows.Forms.TextBox();
            this.textBox69 = new System.Windows.Forms.TextBox();
            this.textBox66 = new System.Windows.Forms.TextBox();
            this.textBox68 = new System.Windows.Forms.TextBox();
            this.textBox67 = new System.Windows.Forms.TextBox();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.button3 = new System.Windows.Forms.Button();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.comboBox24 = new System.Windows.Forms.ComboBox();
            this.comboBox25 = new System.Windows.Forms.ComboBox();
            this.dateTimePicker13 = new System.Windows.Forms.DateTimePicker();
            this.label138 = new System.Windows.Forms.Label();
            this.label139 = new System.Windows.Forms.Label();
            this.label140 = new System.Windows.Forms.Label();
            this.label141 = new System.Windows.Forms.Label();
            this.label142 = new System.Windows.Forms.Label();
            this.label143 = new System.Windows.Forms.Label();
            this.label144 = new System.Windows.Forms.Label();
            this.label145 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.tabControl4 = new System.Windows.Forms.TabControl();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.comboBox12 = new System.Windows.Forms.ComboBox();
            this.comboBox13 = new System.Windows.Forms.ComboBox();
            this.comboBox8 = new System.Windows.Forms.ComboBox();
            this.comboBox9 = new System.Windows.Forms.ComboBox();
            this.dateTimePicker6 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.label147 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.textBox118 = new System.Windows.Forms.TextBox();
            this.textBox96 = new System.Windows.Forms.TextBox();
            this.textBox95 = new System.Windows.Forms.TextBox();
            this.button39 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.dataGridView7 = new System.Windows.Forms.DataGridView();
            this.tabPage12 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.comboBox37 = new System.Windows.Forms.ComboBox();
            this.dateTimePicker8 = new System.Windows.Forms.DateTimePicker();
            this.label148 = new System.Windows.Forms.Label();
            this.dateTimePicker4 = new System.Windows.Forms.DateTimePicker();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.textBox119 = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.button36 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.dataGridView8 = new System.Windows.Forms.DataGridView();
            this.tabPage13 = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.comboBox32 = new System.Windows.Forms.ComboBox();
            this.comboBox33 = new System.Windows.Forms.ComboBox();
            this.comboBox28 = new System.Windows.Forms.ComboBox();
            this.comboBox29 = new System.Windows.Forms.ComboBox();
            this.label81 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.textBox120 = new System.Windows.Forms.TextBox();
            this.button33 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.dataGridView9 = new System.Windows.Forms.DataGridView();
            this.tabPage14 = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.button14 = new System.Windows.Forms.Button();
            this.comboBox20 = new System.Windows.Forms.ComboBox();
            this.comboBox21 = new System.Windows.Forms.ComboBox();
            this.comboBox16 = new System.Windows.Forms.ComboBox();
            this.comboBox17 = new System.Windows.Forms.ComboBox();
            this.dateTimePicker10 = new System.Windows.Forms.DateTimePicker();
            this.label149 = new System.Windows.Forms.Label();
            this.dateTimePicker5 = new System.Windows.Forms.DateTimePicker();
            this.label91 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.textBox121 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.dataGridView10 = new System.Windows.Forms.DataGridView();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox115 = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.textBox97 = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.textBox100 = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.textBox101 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.textBox102 = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.textBox103 = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.textBox107 = new System.Windows.Forms.TextBox();
            this.button13 = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.справкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.руководствоПользователяToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabPage4.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tabPage1.SuspendLayout();
            this.groupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.tabControl4.SuspendLayout();
            this.tabPage11.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).BeginInit();
            this.tabPage12.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView8)).BeginInit();
            this.tabPage13.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView9)).BeginInit();
            this.tabPage14.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView10)).BeginInit();
            this.tabPage8.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 533);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(166, 43);
            this.button1.TabIndex = 1;
            this.button1.Text = "Подключение к БД";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.groupBox7);
            this.tabPage4.Controls.Add(this.button19);
            this.tabPage4.Controls.Add(this.button18);
            this.tabPage4.Controls.Add(this.dataGridView4);
            this.tabPage4.Controls.Add(this.button11);
            this.tabPage4.Controls.Add(this.button8);
            this.tabPage4.Cursor = System.Windows.Forms.Cursors.Default;
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1359, 404);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Услуги";
            this.tabPage4.UseVisualStyleBackColor = true;
            this.tabPage4.Click += new System.EventHandler(this.tabPage4_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.label1);
            this.groupBox7.Controls.Add(this.textBox1);
            this.groupBox7.Controls.Add(this.label102);
            this.groupBox7.Controls.Add(this.label103);
            this.groupBox7.Controls.Add(this.label104);
            this.groupBox7.Controls.Add(this.textBox48);
            this.groupBox7.Controls.Add(this.textBox46);
            this.groupBox7.Controls.Add(this.textBox47);
            this.groupBox7.Location = new System.Drawing.Point(679, 32);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(325, 240);
            this.groupBox7.TabIndex = 82;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Операции";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 166);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 17);
            this.label1.TabIndex = 92;
            this.label1.Text = "Фильтр услуг";
            this.label1.UseWaitCursor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(122, 163);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 22);
            this.textBox1.TabIndex = 91;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged_1);
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Location = new System.Drawing.Point(19, 100);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(97, 17);
            this.label102.TabIndex = 90;
            this.label102.Text = "Цена за день";
            this.label102.UseWaitCursor = true;
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Location = new System.Drawing.Point(83, 72);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(33, 17);
            this.label103.TabIndex = 89;
            this.label103.Text = "Тип";
            this.label103.UseWaitCursor = true;
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Location = new System.Drawing.Point(44, 44);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(72, 17);
            this.label104.TabIndex = 88;
            this.label104.Text = "Название";
            this.label104.UseWaitCursor = true;
            // 
            // textBox48
            // 
            this.textBox48.Location = new System.Drawing.Point(122, 97);
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new System.Drawing.Size(100, 22);
            this.textBox48.TabIndex = 39;
            // 
            // textBox46
            // 
            this.textBox46.Location = new System.Drawing.Point(122, 41);
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(100, 22);
            this.textBox46.TabIndex = 37;
            // 
            // textBox47
            // 
            this.textBox47.Location = new System.Drawing.Point(122, 69);
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(100, 22);
            this.textBox47.TabIndex = 38;
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(271, 293);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(130, 43);
            this.button19.TabIndex = 34;
            this.button19.Text = "Добавить";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(407, 293);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(130, 43);
            this.button18.TabIndex = 33;
            this.button18.Text = "Удалить";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // dataGridView4
            // 
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.dataGridView4.Location = new System.Drawing.Point(40, 32);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.RowTemplate.Height = 24;
            this.dataGridView4.Size = new System.Drawing.Size(633, 240);
            this.dataGridView4.TabIndex = 32;
            this.dataGridView4.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView4_CellContentClick_1);
            this.dataGridView4.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView4_RowHeaderMouseClick);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(543, 293);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(130, 43);
            this.button11.TabIndex = 0;
            this.button11.Text = "Редактировать";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click_1);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(40, 293);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(110, 43);
            this.button8.TabIndex = 6;
            this.button8.Text = "Услуги";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.UseWaitCursor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox8);
            this.tabPage3.Controls.Add(this.button20);
            this.tabPage3.Controls.Add(this.button21);
            this.tabPage3.Controls.Add(this.button22);
            this.tabPage3.Controls.Add(this.dataGridView3);
            this.tabPage3.Controls.Add(this.button4);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1359, 404);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Классы";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.comboBox38);
            this.groupBox8.Controls.Add(this.comboBox39);
            this.groupBox8.Controls.Add(this.label111);
            this.groupBox8.Controls.Add(this.label112);
            this.groupBox8.Controls.Add(this.label113);
            this.groupBox8.Controls.Add(this.textBox57);
            this.groupBox8.Controls.Add(this.textBox56);
            this.groupBox8.Location = new System.Drawing.Point(653, 40);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(388, 240);
            this.groupBox8.TabIndex = 59;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Операции";
            this.groupBox8.Enter += new System.EventHandler(this.groupBox8_Enter);
            // 
            // comboBox38
            // 
            this.comboBox38.FormattingEnabled = true;
            this.comboBox38.Location = new System.Drawing.Point(242, 42);
            this.comboBox38.Name = "comboBox38";
            this.comboBox38.Size = new System.Drawing.Size(117, 24);
            this.comboBox38.TabIndex = 110;
            // 
            // comboBox39
            // 
            this.comboBox39.FormattingEnabled = true;
            this.comboBox39.Location = new System.Drawing.Point(198, 42);
            this.comboBox39.Name = "comboBox39";
            this.comboBox39.Size = new System.Drawing.Size(38, 24);
            this.comboBox39.TabIndex = 109;
            this.comboBox39.SelectedIndexChanged += new System.EventHandler(this.comboBox39_SelectedIndexChanged);
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Location = new System.Drawing.Point(128, 97);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(64, 17);
            this.label111.TabIndex = 64;
            this.label111.Text = "Кабинет";
            this.label111.UseWaitCursor = true;
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.Location = new System.Drawing.Point(145, 69);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(47, 17);
            this.label112.TabIndex = 63;
            this.label112.Text = "Класс";
            this.label112.UseWaitCursor = true;
            // 
            // label113
            // 
            this.label113.AutoSize = true;
            this.label113.Location = new System.Drawing.Point(24, 41);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(168, 17);
            this.label113.TabIndex = 62;
            this.label113.Text = "Классный руководитель";
            this.label113.UseWaitCursor = true;
            // 
            // textBox57
            // 
            this.textBox57.Location = new System.Drawing.Point(198, 97);
            this.textBox57.Name = "textBox57";
            this.textBox57.Size = new System.Drawing.Size(100, 22);
            this.textBox57.TabIndex = 41;
            this.textBox57.UseWaitCursor = true;
            // 
            // textBox56
            // 
            this.textBox56.Location = new System.Drawing.Point(198, 69);
            this.textBox56.Name = "textBox56";
            this.textBox56.Size = new System.Drawing.Size(100, 22);
            this.textBox56.TabIndex = 40;
            this.textBox56.UseWaitCursor = true;
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(524, 296);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(123, 43);
            this.button20.TabIndex = 58;
            this.button20.Text = "Редактировать";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.UseWaitCursor = true;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(408, 296);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(110, 43);
            this.button21.TabIndex = 57;
            this.button21.Text = "Удалить";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.UseWaitCursor = true;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(292, 296);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(110, 43);
            this.button22.TabIndex = 56;
            this.button22.Text = "Добавить";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.UseWaitCursor = true;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.dataGridView3.Location = new System.Drawing.Point(14, 40);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowTemplate.Height = 24;
            this.dataGridView3.Size = new System.Drawing.Size(633, 240);
            this.dataGridView3.TabIndex = 32;
            this.dataGridView3.UseWaitCursor = true;
            this.dataGridView3.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellContentClick_1);
            this.dataGridView3.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView3_RowHeaderMouseClick);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(14, 296);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(110, 43);
            this.button4.TabIndex = 4;
            this.button4.Text = "Классы";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.UseWaitCursor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox9);
            this.tabPage2.Controls.Add(this.button23);
            this.tabPage2.Controls.Add(this.button24);
            this.tabPage2.Controls.Add(this.button25);
            this.tabPage2.Controls.Add(this.dataGridView2);
            this.tabPage2.Controls.Add(this.button3);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1359, 404);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Учителя";
            this.tabPage2.UseVisualStyleBackColor = true;
            this.tabPage2.UseWaitCursor = true;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.label122);
            this.groupBox9.Controls.Add(this.label123);
            this.groupBox9.Controls.Add(this.label124);
            this.groupBox9.Controls.Add(this.label125);
            this.groupBox9.Controls.Add(this.label126);
            this.groupBox9.Controls.Add(this.textBox70);
            this.groupBox9.Controls.Add(this.textBox69);
            this.groupBox9.Controls.Add(this.textBox66);
            this.groupBox9.Controls.Add(this.textBox68);
            this.groupBox9.Controls.Add(this.textBox67);
            this.groupBox9.Location = new System.Drawing.Point(662, 20);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(285, 301);
            this.groupBox9.TabIndex = 60;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Операции";
            this.groupBox9.UseWaitCursor = true;
            // 
            // label122
            // 
            this.label122.AutoSize = true;
            this.label122.Location = new System.Drawing.Point(36, 161);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(68, 17);
            this.label122.TabIndex = 69;
            this.label122.Text = "Телефон";
            this.label122.UseWaitCursor = true;
            // 
            // label123
            // 
            this.label123.AutoSize = true;
            this.label123.Location = new System.Drawing.Point(55, 133);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(49, 17);
            this.label123.TabIndex = 68;
            this.label123.Text = "Почта";
            this.label123.UseWaitCursor = true;
            // 
            // label124
            // 
            this.label124.AutoSize = true;
            this.label124.Location = new System.Drawing.Point(56, 105);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(48, 17);
            this.label124.TabIndex = 67;
            this.label124.Text = "Адрес";
            this.label124.UseWaitCursor = true;
            // 
            // label125
            // 
            this.label125.AutoSize = true;
            this.label125.Location = new System.Drawing.Point(38, 77);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(66, 17);
            this.label125.TabIndex = 66;
            this.label125.Text = "Предмет";
            this.label125.UseWaitCursor = true;
            // 
            // label126
            // 
            this.label126.AutoSize = true;
            this.label126.Location = new System.Drawing.Point(62, 49);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(42, 17);
            this.label126.TabIndex = 65;
            this.label126.Text = "ФИО";
            this.label126.UseWaitCursor = true;
            // 
            // textBox70
            // 
            this.textBox70.Location = new System.Drawing.Point(110, 158);
            this.textBox70.Name = "textBox70";
            this.textBox70.Size = new System.Drawing.Size(100, 22);
            this.textBox70.TabIndex = 48;
            this.textBox70.UseWaitCursor = true;
            // 
            // textBox69
            // 
            this.textBox69.Location = new System.Drawing.Point(110, 130);
            this.textBox69.Name = "textBox69";
            this.textBox69.Size = new System.Drawing.Size(100, 22);
            this.textBox69.TabIndex = 47;
            this.textBox69.UseWaitCursor = true;
            // 
            // textBox66
            // 
            this.textBox66.Location = new System.Drawing.Point(110, 46);
            this.textBox66.Name = "textBox66";
            this.textBox66.Size = new System.Drawing.Size(100, 22);
            this.textBox66.TabIndex = 44;
            this.textBox66.UseWaitCursor = true;
            // 
            // textBox68
            // 
            this.textBox68.Location = new System.Drawing.Point(110, 102);
            this.textBox68.Name = "textBox68";
            this.textBox68.Size = new System.Drawing.Size(100, 22);
            this.textBox68.TabIndex = 46;
            this.textBox68.UseWaitCursor = true;
            // 
            // textBox67
            // 
            this.textBox67.Location = new System.Drawing.Point(110, 74);
            this.textBox67.Name = "textBox67";
            this.textBox67.Size = new System.Drawing.Size(100, 22);
            this.textBox67.TabIndex = 45;
            this.textBox67.UseWaitCursor = true;
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(533, 278);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(123, 43);
            this.button23.TabIndex = 59;
            this.button23.Text = "Редактировать";
            this.button23.UseVisualStyleBackColor = true;
            this.button23.UseWaitCursor = true;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(417, 278);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(110, 43);
            this.button24.TabIndex = 58;
            this.button24.Text = "Удалить";
            this.button24.UseVisualStyleBackColor = true;
            this.button24.UseWaitCursor = true;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(301, 278);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(110, 43);
            this.button25.TabIndex = 57;
            this.button25.Text = "Добавить";
            this.button25.UseVisualStyleBackColor = true;
            this.button25.UseWaitCursor = true;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.dataGridView2.Location = new System.Drawing.Point(23, 20);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(633, 240);
            this.dataGridView2.TabIndex = 32;
            this.dataGridView2.UseWaitCursor = true;
            this.dataGridView2.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView2_RowHeaderMouseClick);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(23, 278);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(110, 43);
            this.button3.TabIndex = 3;
            this.button3.Text = "Учителя";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.UseWaitCursor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox10);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Controls.Add(this.button7);
            this.tabPage1.Controls.Add(this.button6);
            this.tabPage1.Controls.Add(this.button5);
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Cursor = System.Windows.Forms.Cursors.Default;
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1359, 404);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Ученики";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.label2);
            this.groupBox10.Controls.Add(this.textBox2);
            this.groupBox10.Controls.Add(this.comboBox24);
            this.groupBox10.Controls.Add(this.comboBox25);
            this.groupBox10.Controls.Add(this.dateTimePicker13);
            this.groupBox10.Controls.Add(this.label138);
            this.groupBox10.Controls.Add(this.label139);
            this.groupBox10.Controls.Add(this.label140);
            this.groupBox10.Controls.Add(this.label141);
            this.groupBox10.Controls.Add(this.label142);
            this.groupBox10.Controls.Add(this.label143);
            this.groupBox10.Controls.Add(this.label144);
            this.groupBox10.Controls.Add(this.label145);
            this.groupBox10.Controls.Add(this.label3);
            this.groupBox10.Controls.Add(this.textBox13);
            this.groupBox10.Controls.Add(this.textBox14);
            this.groupBox10.Controls.Add(this.textBox16);
            this.groupBox10.Controls.Add(this.textBox18);
            this.groupBox10.Controls.Add(this.textBox19);
            this.groupBox10.Controls.Add(this.textBox20);
            this.groupBox10.Location = new System.Drawing.Point(677, 37);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(366, 361);
            this.groupBox10.TabIndex = 82;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Операции";
            this.groupBox10.Enter += new System.EventHandler(this.groupBox10_Enter);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 312);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(184, 17);
            this.label2.TabIndex = 112;
            this.label2.Text = "Фильтр по ФИО ученикам";
            this.label2.UseWaitCursor = true;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(203, 309);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 22);
            this.textBox2.TabIndex = 111;
            this.textBox2.UseWaitCursor = true;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged_1);
            // 
            // comboBox24
            // 
            this.comboBox24.FormattingEnabled = true;
            this.comboBox24.Location = new System.Drawing.Point(183, 111);
            this.comboBox24.Name = "comboBox24";
            this.comboBox24.Size = new System.Drawing.Size(56, 24);
            this.comboBox24.TabIndex = 110;
            // 
            // comboBox25
            // 
            this.comboBox25.FormattingEnabled = true;
            this.comboBox25.Location = new System.Drawing.Point(139, 111);
            this.comboBox25.Name = "comboBox25";
            this.comboBox25.Size = new System.Drawing.Size(38, 24);
            this.comboBox25.TabIndex = 109;
            this.comboBox25.SelectedIndexChanged += new System.EventHandler(this.comboBox25_SelectedIndexChanged);
            // 
            // dateTimePicker13
            // 
            this.dateTimePicker13.Location = new System.Drawing.Point(139, 166);
            this.dateTimePicker13.Name = "dateTimePicker13";
            this.dateTimePicker13.Size = new System.Drawing.Size(139, 22);
            this.dateTimePicker13.TabIndex = 102;
            this.dateTimePicker13.ValueChanged += new System.EventHandler(this.dateTimePicker13_ValueChanged);
            // 
            // label138
            // 
            this.label138.AutoSize = true;
            this.label138.Location = new System.Drawing.Point(65, 253);
            this.label138.Name = "label138";
            this.label138.Size = new System.Drawing.Size(68, 17);
            this.label138.TabIndex = 100;
            this.label138.Text = "Телефон";
            this.label138.UseWaitCursor = true;
            // 
            // label139
            // 
            this.label139.AutoSize = true;
            this.label139.Location = new System.Drawing.Point(78, 226);
            this.label139.Name = "label139";
            this.label139.Size = new System.Drawing.Size(55, 17);
            this.label139.TabIndex = 99;
            this.label139.Text = "Льготы";
            this.label139.UseWaitCursor = true;
            // 
            // label140
            // 
            this.label140.AutoSize = true;
            this.label140.Location = new System.Drawing.Point(84, 197);
            this.label140.Name = "label140";
            this.label140.Size = new System.Drawing.Size(49, 17);
            this.label140.TabIndex = 98;
            this.label140.Text = "Почта";
            this.label140.UseWaitCursor = true;
            // 
            // label141
            // 
            this.label141.AutoSize = true;
            this.label141.Location = new System.Drawing.Point(22, 168);
            this.label141.Name = "label141";
            this.label141.Size = new System.Drawing.Size(111, 17);
            this.label141.TabIndex = 97;
            this.label141.Text = "Дата рождения";
            this.label141.UseWaitCursor = true;
            // 
            // label142
            // 
            this.label142.AutoSize = true;
            this.label142.Location = new System.Drawing.Point(85, 141);
            this.label142.Name = "label142";
            this.label142.Size = new System.Drawing.Size(48, 17);
            this.label142.TabIndex = 96;
            this.label142.Text = "Адрес";
            this.label142.UseWaitCursor = true;
            // 
            // label143
            // 
            this.label143.AutoSize = true;
            this.label143.Location = new System.Drawing.Point(86, 114);
            this.label143.Name = "label143";
            this.label143.Size = new System.Drawing.Size(47, 17);
            this.label143.TabIndex = 95;
            this.label143.Text = "Класс";
            this.label143.UseWaitCursor = true;
            // 
            // label144
            // 
            this.label144.AutoSize = true;
            this.label144.Location = new System.Drawing.Point(99, 86);
            this.label144.Name = "label144";
            this.label144.Size = new System.Drawing.Size(34, 17);
            this.label144.TabIndex = 94;
            this.label144.Text = "Пол";
            this.label144.UseWaitCursor = true;
            // 
            // label145
            // 
            this.label145.AutoSize = true;
            this.label145.Location = new System.Drawing.Point(91, 56);
            this.label145.Name = "label145";
            this.label145.Size = new System.Drawing.Size(42, 17);
            this.label145.TabIndex = 93;
            this.label145.Text = "ФИО";
            this.label145.UseWaitCursor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(110, 33);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(118, 17);
            this.label3.TabIndex = 30;
            this.label3.Text = "Редактирование";
            this.label3.UseWaitCursor = true;
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(139, 53);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(100, 22);
            this.textBox13.TabIndex = 29;
            this.textBox13.UseWaitCursor = true;
            this.textBox13.TextChanged += new System.EventHandler(this.textBox13_TextChanged);
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(139, 81);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(100, 22);
            this.textBox14.TabIndex = 28;
            this.textBox14.UseWaitCursor = true;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(139, 137);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(100, 22);
            this.textBox16.TabIndex = 26;
            this.textBox16.UseWaitCursor = true;
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(139, 193);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(100, 22);
            this.textBox18.TabIndex = 24;
            this.textBox18.UseWaitCursor = true;
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(139, 223);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(100, 22);
            this.textBox19.TabIndex = 23;
            this.textBox19.UseWaitCursor = true;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(139, 253);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(100, 22);
            this.textBox20.TabIndex = 22;
            this.textBox20.UseWaitCursor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.dataGridView1.Location = new System.Drawing.Point(26, 37);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(633, 240);
            this.dataGridView1.TabIndex = 31;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick_1);
            this.dataGridView1.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView1_RowHeaderMouseClick);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(530, 293);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(129, 43);
            this.button7.TabIndex = 5;
            this.button7.Text = "Редактировать";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(402, 293);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(110, 43);
            this.button6.TabIndex = 4;
            this.button6.Text = "Удалить";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.UseWaitCursor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(275, 293);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(110, 43);
            this.button5.TabIndex = 3;
            this.button5.Text = "Добавить";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.UseWaitCursor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(26, 290);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(110, 43);
            this.button2.TabIndex = 2;
            this.button2.Text = "Ученик";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.UseWaitCursor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(15, 6);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1367, 433);
            this.tabControl1.TabIndex = 5;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage7);
            this.tabControl2.Controls.Add(this.tabPage8);
            this.tabControl2.Controls.Add(this.tabPage5);
            this.tabControl2.Location = new System.Drawing.Point(12, 38);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(1607, 489);
            this.tabControl2.TabIndex = 32;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.tabControl4);
            this.tabPage7.Location = new System.Drawing.Point(4, 25);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(1599, 460);
            this.tabPage7.TabIndex = 0;
            this.tabPage7.Text = "Рабочие таблицы";
            this.tabPage7.UseVisualStyleBackColor = true;
            this.tabPage7.Click += new System.EventHandler(this.tabPage7_Click);
            // 
            // tabControl4
            // 
            this.tabControl4.Controls.Add(this.tabPage11);
            this.tabControl4.Controls.Add(this.tabPage12);
            this.tabControl4.Controls.Add(this.tabPage13);
            this.tabControl4.Controls.Add(this.tabPage14);
            this.tabControl4.Location = new System.Drawing.Point(6, 6);
            this.tabControl4.Name = "tabControl4";
            this.tabControl4.SelectedIndex = 0;
            this.tabControl4.Size = new System.Drawing.Size(1405, 369);
            this.tabControl4.TabIndex = 0;
            // 
            // tabPage11
            // 
            this.tabPage11.Controls.Add(this.groupBox3);
            this.tabPage11.Controls.Add(this.button39);
            this.tabPage11.Controls.Add(this.button40);
            this.tabPage11.Controls.Add(this.button41);
            this.tabPage11.Controls.Add(this.button29);
            this.tabPage11.Controls.Add(this.dataGridView7);
            this.tabPage11.Location = new System.Drawing.Point(4, 25);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage11.Size = new System.Drawing.Size(1397, 340);
            this.tabPage11.TabIndex = 0;
            this.tabPage11.Text = "Договор";
            this.tabPage11.UseVisualStyleBackColor = true;
            this.tabPage11.Click += new System.EventHandler(this.tabPage11_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.comboBox12);
            this.groupBox3.Controls.Add(this.comboBox13);
            this.groupBox3.Controls.Add(this.comboBox8);
            this.groupBox3.Controls.Add(this.comboBox9);
            this.groupBox3.Controls.Add(this.dateTimePicker6);
            this.groupBox3.Controls.Add(this.dateTimePicker3);
            this.groupBox3.Controls.Add(this.label147);
            this.groupBox3.Controls.Add(this.label58);
            this.groupBox3.Controls.Add(this.label59);
            this.groupBox3.Controls.Add(this.label60);
            this.groupBox3.Controls.Add(this.label62);
            this.groupBox3.Controls.Add(this.label63);
            this.groupBox3.Controls.Add(this.label45);
            this.groupBox3.Controls.Add(this.textBox118);
            this.groupBox3.Controls.Add(this.textBox96);
            this.groupBox3.Controls.Add(this.textBox95);
            this.groupBox3.Location = new System.Drawing.Point(662, 15);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(719, 325);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Операции";
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // comboBox12
            // 
            this.comboBox12.FormattingEnabled = true;
            this.comboBox12.Location = new System.Drawing.Point(208, 81);
            this.comboBox12.Name = "comboBox12";
            this.comboBox12.Size = new System.Drawing.Size(36, 24);
            this.comboBox12.TabIndex = 104;
            this.comboBox12.SelectedIndexChanged += new System.EventHandler(this.comboBox12_SelectedIndexChanged);
            // 
            // comboBox13
            // 
            this.comboBox13.FormattingEnabled = true;
            this.comboBox13.Location = new System.Drawing.Point(250, 80);
            this.comboBox13.Name = "comboBox13";
            this.comboBox13.Size = new System.Drawing.Size(113, 24);
            this.comboBox13.TabIndex = 103;
            // 
            // comboBox8
            // 
            this.comboBox8.FormattingEnabled = true;
            this.comboBox8.Location = new System.Drawing.Point(208, 51);
            this.comboBox8.Name = "comboBox8";
            this.comboBox8.Size = new System.Drawing.Size(36, 24);
            this.comboBox8.TabIndex = 100;
            this.comboBox8.SelectedIndexChanged += new System.EventHandler(this.comboBox8_SelectedIndexChanged);
            // 
            // comboBox9
            // 
            this.comboBox9.FormattingEnabled = true;
            this.comboBox9.Location = new System.Drawing.Point(250, 50);
            this.comboBox9.Name = "comboBox9";
            this.comboBox9.Size = new System.Drawing.Size(113, 24);
            this.comboBox9.TabIndex = 99;
            this.comboBox9.SelectedIndexChanged += new System.EventHandler(this.comboBox9_SelectedIndexChanged);
            // 
            // dateTimePicker6
            // 
            this.dateTimePicker6.Location = new System.Drawing.Point(208, 109);
            this.dateTimePicker6.Name = "dateTimePicker6";
            this.dateTimePicker6.Size = new System.Drawing.Size(139, 22);
            this.dateTimePicker6.TabIndex = 96;
            this.dateTimePicker6.ValueChanged += new System.EventHandler(this.dateTimePicker6_ValueChanged);
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.CustomFormat = "yyyy-MM-dd";
            this.dateTimePicker3.Location = new System.Drawing.Point(208, 223);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(200, 22);
            this.dateTimePicker3.TabIndex = 94;
            this.dateTimePicker3.Value = new System.DateTime(2022, 3, 5, 0, 0, 0, 0);
            this.dateTimePicker3.ValueChanged += new System.EventHandler(this.dateTimePicker3_ValueChanged);
            // 
            // label147
            // 
            this.label147.AutoSize = true;
            this.label147.Location = new System.Drawing.Point(4, 228);
            this.label147.Name = "label147";
            this.label147.Size = new System.Drawing.Size(198, 17);
            this.label147.TabIndex = 93;
            this.label147.Text = "Фильтр по дате заключения";
            this.label147.UseWaitCursor = true;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(97, 165);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(105, 17);
            this.label58.TabIndex = 92;
            this.label58.Text = "Срок действия";
            this.label58.UseWaitCursor = true;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(93, 138);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(109, 17);
            this.label59.TabIndex = 91;
            this.label59.Text = "ФИО родителя";
            this.label59.UseWaitCursor = true;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(76, 109);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(126, 17);
            this.label60.TabIndex = 90;
            this.label60.Text = "Дата заключения";
            this.label60.UseWaitCursor = true;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(105, 81);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(97, 17);
            this.label62.TabIndex = 88;
            this.label62.Text = "Номер услуги";
            this.label62.UseWaitCursor = true;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(93, 53);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(109, 17);
            this.label63.TabIndex = 87;
            this.label63.Text = "Номер ученика";
            this.label63.UseWaitCursor = true;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(66, 193);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(136, 17);
            this.label45.TabIndex = 79;
            this.label45.Text = "Фильтр по ученику";
            this.label45.UseWaitCursor = true;
            this.label45.Click += new System.EventHandler(this.label45_Click);
            // 
            // textBox118
            // 
            this.textBox118.Location = new System.Drawing.Point(208, 190);
            this.textBox118.Name = "textBox118";
            this.textBox118.Size = new System.Drawing.Size(100, 22);
            this.textBox118.TabIndex = 78;
            this.textBox118.TextChanged += new System.EventHandler(this.textBox118_TextChanged_1);
            // 
            // textBox96
            // 
            this.textBox96.Location = new System.Drawing.Point(208, 162);
            this.textBox96.Name = "textBox96";
            this.textBox96.Size = new System.Drawing.Size(100, 22);
            this.textBox96.TabIndex = 74;
            this.textBox96.UseWaitCursor = true;
            // 
            // textBox95
            // 
            this.textBox95.Location = new System.Drawing.Point(208, 134);
            this.textBox95.Name = "textBox95";
            this.textBox95.Size = new System.Drawing.Size(100, 22);
            this.textBox95.TabIndex = 73;
            this.textBox95.UseWaitCursor = true;
            // 
            // button39
            // 
            this.button39.Location = new System.Drawing.Point(515, 275);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(123, 43);
            this.button39.TabIndex = 61;
            this.button39.Text = "Редактировать";
            this.button39.UseVisualStyleBackColor = true;
            this.button39.UseWaitCursor = true;
            this.button39.Click += new System.EventHandler(this.button39_Click);
            // 
            // button40
            // 
            this.button40.Location = new System.Drawing.Point(399, 275);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(110, 43);
            this.button40.TabIndex = 60;
            this.button40.Text = "Удалить";
            this.button40.UseVisualStyleBackColor = true;
            this.button40.UseWaitCursor = true;
            this.button40.Click += new System.EventHandler(this.button40_Click);
            // 
            // button41
            // 
            this.button41.Location = new System.Drawing.Point(283, 275);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(110, 43);
            this.button41.TabIndex = 59;
            this.button41.Text = "Добавить";
            this.button41.UseVisualStyleBackColor = true;
            this.button41.UseWaitCursor = true;
            this.button41.Click += new System.EventHandler(this.button41_Click);
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(19, 275);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(116, 43);
            this.button29.TabIndex = 3;
            this.button29.Text = "Договор";
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Click += new System.EventHandler(this.button29_Click);
            // 
            // dataGridView7
            // 
            this.dataGridView7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView7.Location = new System.Drawing.Point(19, 15);
            this.dataGridView7.Name = "dataGridView7";
            this.dataGridView7.RowTemplate.Height = 24;
            this.dataGridView7.Size = new System.Drawing.Size(619, 240);
            this.dataGridView7.TabIndex = 0;
            this.dataGridView7.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView7_CellContentClick);
            this.dataGridView7.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView7_RowHeaderMouseClick);
            // 
            // tabPage12
            // 
            this.tabPage12.Controls.Add(this.groupBox4);
            this.tabPage12.Controls.Add(this.button36);
            this.tabPage12.Controls.Add(this.button37);
            this.tabPage12.Controls.Add(this.button28);
            this.tabPage12.Controls.Add(this.button38);
            this.tabPage12.Controls.Add(this.dataGridView8);
            this.tabPage12.Location = new System.Drawing.Point(4, 25);
            this.tabPage12.Name = "tabPage12";
            this.tabPage12.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage12.Size = new System.Drawing.Size(1397, 340);
            this.tabPage12.TabIndex = 1;
            this.tabPage12.Text = "Учебные занятия";
            this.tabPage12.UseVisualStyleBackColor = true;
            this.tabPage12.Click += new System.EventHandler(this.tabPage12_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.comboBox37);
            this.groupBox4.Controls.Add(this.dateTimePicker8);
            this.groupBox4.Controls.Add(this.label148);
            this.groupBox4.Controls.Add(this.dateTimePicker4);
            this.groupBox4.Controls.Add(this.label71);
            this.groupBox4.Controls.Add(this.label72);
            this.groupBox4.Controls.Add(this.label73);
            this.groupBox4.Controls.Add(this.label74);
            this.groupBox4.Controls.Add(this.label75);
            this.groupBox4.Controls.Add(this.label46);
            this.groupBox4.Controls.Add(this.textBox119);
            this.groupBox4.Controls.Add(this.textBox40);
            this.groupBox4.Controls.Add(this.textBox39);
            this.groupBox4.Controls.Add(this.textBox38);
            this.groupBox4.Location = new System.Drawing.Point(642, 16);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(434, 240);
            this.groupBox4.TabIndex = 81;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Операции";
            // 
            // comboBox37
            // 
            this.comboBox37.FormattingEnabled = true;
            this.comboBox37.Location = new System.Drawing.Point(238, 68);
            this.comboBox37.Name = "comboBox37";
            this.comboBox37.Size = new System.Drawing.Size(45, 24);
            this.comboBox37.TabIndex = 107;
            this.comboBox37.SelectedIndexChanged += new System.EventHandler(this.comboBox37_SelectedIndexChanged);
            // 
            // dateTimePicker8
            // 
            this.dateTimePicker8.Location = new System.Drawing.Point(238, 42);
            this.dateTimePicker8.Name = "dateTimePicker8";
            this.dateTimePicker8.Size = new System.Drawing.Size(139, 22);
            this.dateTimePicker8.TabIndex = 98;
            this.dateTimePicker8.ValueChanged += new System.EventHandler(this.dateTimePicker8_ValueChanged);
            // 
            // label148
            // 
            this.label148.AutoSize = true;
            this.label148.Location = new System.Drawing.Point(18, 210);
            this.label148.Name = "label148";
            this.label148.Size = new System.Drawing.Size(114, 17);
            this.label148.TabIndex = 96;
            this.label148.Text = "Фильтр по дате";
            this.label148.UseWaitCursor = true;
            // 
            // dateTimePicker4
            // 
            this.dateTimePicker4.CustomFormat = "yyyy-MM-dd";
            this.dateTimePicker4.Location = new System.Drawing.Point(138, 205);
            this.dateTimePicker4.Name = "dateTimePicker4";
            this.dateTimePicker4.Size = new System.Drawing.Size(200, 22);
            this.dateTimePicker4.TabIndex = 95;
            this.dateTimePicker4.Value = new System.DateTime(2022, 3, 5, 0, 0, 0, 0);
            this.dateTimePicker4.ValueChanged += new System.EventHandler(this.dateTimePicker4_ValueChanged);
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(168, 155);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(64, 17);
            this.label71.TabIndex = 93;
            this.label71.Text = "Кабинет";
            this.label71.UseWaitCursor = true;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(94, 127);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(138, 17);
            this.label72.TabIndex = 92;
            this.label72.Text = "Домашнее задание";
            this.label72.UseWaitCursor = true;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(190, 101);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(42, 17);
            this.label73.TabIndex = 91;
            this.label73.Text = "Тема";
            this.label73.UseWaitCursor = true;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(131, 71);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(101, 17);
            this.label74.TabIndex = 90;
            this.label74.Text = "Номер группы";
            this.label74.UseWaitCursor = true;
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(190, 43);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(42, 17);
            this.label75.TabIndex = 89;
            this.label75.Text = "Дата";
            this.label75.UseWaitCursor = true;
            this.label75.Click += new System.EventHandler(this.label75_Click);
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(43, 183);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(189, 17);
            this.label46.TabIndex = 80;
            this.label46.Text = "Фильтр по номеру занятия";
            this.label46.UseWaitCursor = true;
            this.label46.Click += new System.EventHandler(this.label46_Click);
            // 
            // textBox119
            // 
            this.textBox119.Location = new System.Drawing.Point(238, 180);
            this.textBox119.Name = "textBox119";
            this.textBox119.Size = new System.Drawing.Size(100, 22);
            this.textBox119.TabIndex = 79;
            this.textBox119.TextChanged += new System.EventHandler(this.textBox119_TextChanged);
            // 
            // textBox40
            // 
            this.textBox40.Location = new System.Drawing.Point(238, 152);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(100, 22);
            this.textBox40.TabIndex = 74;
            this.textBox40.UseWaitCursor = true;
            // 
            // textBox39
            // 
            this.textBox39.Location = new System.Drawing.Point(238, 124);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(100, 22);
            this.textBox39.TabIndex = 73;
            this.textBox39.UseWaitCursor = true;
            // 
            // textBox38
            // 
            this.textBox38.Location = new System.Drawing.Point(238, 96);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(100, 22);
            this.textBox38.TabIndex = 72;
            this.textBox38.UseWaitCursor = true;
            // 
            // button36
            // 
            this.button36.Location = new System.Drawing.Point(513, 277);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(123, 43);
            this.button36.TabIndex = 61;
            this.button36.Text = "Редактировать";
            this.button36.UseVisualStyleBackColor = true;
            this.button36.UseWaitCursor = true;
            this.button36.Click += new System.EventHandler(this.button36_Click);
            // 
            // button37
            // 
            this.button37.Location = new System.Drawing.Point(397, 277);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(110, 43);
            this.button37.TabIndex = 60;
            this.button37.Text = "Удалить";
            this.button37.UseVisualStyleBackColor = true;
            this.button37.UseWaitCursor = true;
            this.button37.Click += new System.EventHandler(this.button37_Click);
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(17, 277);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(151, 43);
            this.button28.TabIndex = 3;
            this.button28.Text = "Учебные занятия";
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.button28_Click);
            // 
            // button38
            // 
            this.button38.Location = new System.Drawing.Point(281, 277);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(110, 43);
            this.button38.TabIndex = 59;
            this.button38.Text = "Добавить";
            this.button38.UseVisualStyleBackColor = true;
            this.button38.UseWaitCursor = true;
            this.button38.Click += new System.EventHandler(this.button38_Click);
            // 
            // dataGridView8
            // 
            this.dataGridView8.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView8.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView8.Location = new System.Drawing.Point(17, 16);
            this.dataGridView8.Name = "dataGridView8";
            this.dataGridView8.RowTemplate.Height = 24;
            this.dataGridView8.Size = new System.Drawing.Size(619, 240);
            this.dataGridView8.TabIndex = 1;
            this.dataGridView8.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView8_CellContentClick);
            this.dataGridView8.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView8_RowHeaderMouseClick);
            // 
            // tabPage13
            // 
            this.tabPage13.Controls.Add(this.groupBox5);
            this.tabPage13.Controls.Add(this.button33);
            this.tabPage13.Controls.Add(this.button34);
            this.tabPage13.Controls.Add(this.button27);
            this.tabPage13.Controls.Add(this.button35);
            this.tabPage13.Controls.Add(this.dataGridView9);
            this.tabPage13.Location = new System.Drawing.Point(4, 25);
            this.tabPage13.Name = "tabPage13";
            this.tabPage13.Size = new System.Drawing.Size(1397, 340);
            this.tabPage13.TabIndex = 2;
            this.tabPage13.Text = "Группа";
            this.tabPage13.UseVisualStyleBackColor = true;
            this.tabPage13.Click += new System.EventHandler(this.tabPage13_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.comboBox32);
            this.groupBox5.Controls.Add(this.comboBox33);
            this.groupBox5.Controls.Add(this.comboBox28);
            this.groupBox5.Controls.Add(this.comboBox29);
            this.groupBox5.Controls.Add(this.label81);
            this.groupBox5.Controls.Add(this.label82);
            this.groupBox5.Controls.Add(this.label47);
            this.groupBox5.Controls.Add(this.textBox120);
            this.groupBox5.Location = new System.Drawing.Point(648, 24);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(357, 240);
            this.groupBox5.TabIndex = 81;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Операции";
            this.groupBox5.Enter += new System.EventHandler(this.groupBox5_Enter);
            // 
            // comboBox32
            // 
            this.comboBox32.FormattingEnabled = true;
            this.comboBox32.Location = new System.Drawing.Point(190, 69);
            this.comboBox32.Name = "comboBox32";
            this.comboBox32.Size = new System.Drawing.Size(117, 24);
            this.comboBox32.TabIndex = 110;
            this.comboBox32.SelectedIndexChanged += new System.EventHandler(this.comboBox32_SelectedIndexChanged);
            // 
            // comboBox33
            // 
            this.comboBox33.FormattingEnabled = true;
            this.comboBox33.Location = new System.Drawing.Point(146, 69);
            this.comboBox33.Name = "comboBox33";
            this.comboBox33.Size = new System.Drawing.Size(38, 24);
            this.comboBox33.TabIndex = 109;
            this.comboBox33.SelectedIndexChanged += new System.EventHandler(this.comboBox33_SelectedIndexChanged);
            // 
            // comboBox28
            // 
            this.comboBox28.FormattingEnabled = true;
            this.comboBox28.Location = new System.Drawing.Point(190, 40);
            this.comboBox28.Name = "comboBox28";
            this.comboBox28.Size = new System.Drawing.Size(117, 24);
            this.comboBox28.TabIndex = 106;
            // 
            // comboBox29
            // 
            this.comboBox29.FormattingEnabled = true;
            this.comboBox29.Location = new System.Drawing.Point(146, 40);
            this.comboBox29.Name = "comboBox29";
            this.comboBox29.Size = new System.Drawing.Size(38, 24);
            this.comboBox29.TabIndex = 105;
            this.comboBox29.SelectedIndexChanged += new System.EventHandler(this.comboBox29_SelectedIndexChanged);
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(32, 69);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(108, 17);
            this.label81.TabIndex = 87;
            this.label81.Text = "Номер сервиса";
            this.label81.UseWaitCursor = true;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(77, 43);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(63, 17);
            this.label82.TabIndex = 86;
            this.label82.Text = "Учитель";
            this.label82.UseWaitCursor = true;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(21, 102);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(119, 17);
            this.label47.TabIndex = 80;
            this.label47.Text = "Фильтр учителю";
            this.label47.UseWaitCursor = true;
            this.label47.Click += new System.EventHandler(this.label47_Click);
            // 
            // textBox120
            // 
            this.textBox120.Location = new System.Drawing.Point(146, 99);
            this.textBox120.Name = "textBox120";
            this.textBox120.Size = new System.Drawing.Size(100, 22);
            this.textBox120.TabIndex = 79;
            this.textBox120.TextChanged += new System.EventHandler(this.textBox120_TextChanged);
            // 
            // button33
            // 
            this.button33.Location = new System.Drawing.Point(519, 282);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(123, 43);
            this.button33.TabIndex = 61;
            this.button33.Text = "Редактировать";
            this.button33.UseVisualStyleBackColor = true;
            this.button33.UseWaitCursor = true;
            this.button33.Click += new System.EventHandler(this.button33_Click);
            // 
            // button34
            // 
            this.button34.Location = new System.Drawing.Point(403, 282);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(110, 43);
            this.button34.TabIndex = 60;
            this.button34.Text = "Удалить";
            this.button34.UseVisualStyleBackColor = true;
            this.button34.UseWaitCursor = true;
            this.button34.Click += new System.EventHandler(this.button34_Click);
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(23, 282);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(110, 43);
            this.button27.TabIndex = 3;
            this.button27.Text = "Группа";
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            // 
            // button35
            // 
            this.button35.Location = new System.Drawing.Point(287, 282);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(110, 43);
            this.button35.TabIndex = 59;
            this.button35.Text = "Добавить";
            this.button35.UseVisualStyleBackColor = true;
            this.button35.UseWaitCursor = true;
            this.button35.Click += new System.EventHandler(this.button35_Click);
            // 
            // dataGridView9
            // 
            this.dataGridView9.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView9.Location = new System.Drawing.Point(23, 24);
            this.dataGridView9.Name = "dataGridView9";
            this.dataGridView9.RowTemplate.Height = 24;
            this.dataGridView9.Size = new System.Drawing.Size(619, 240);
            this.dataGridView9.TabIndex = 1;
            this.dataGridView9.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView9_RowHeaderMouseClick);
            // 
            // tabPage14
            // 
            this.tabPage14.Controls.Add(this.groupBox6);
            this.tabPage14.Controls.Add(this.button9);
            this.tabPage14.Controls.Add(this.button10);
            this.tabPage14.Controls.Add(this.button12);
            this.tabPage14.Controls.Add(this.button26);
            this.tabPage14.Controls.Add(this.dataGridView10);
            this.tabPage14.Location = new System.Drawing.Point(4, 25);
            this.tabPage14.Name = "tabPage14";
            this.tabPage14.Size = new System.Drawing.Size(1397, 340);
            this.tabPage14.TabIndex = 3;
            this.tabPage14.Text = "Посещения";
            this.tabPage14.UseVisualStyleBackColor = true;
            this.tabPage14.Click += new System.EventHandler(this.tabPage14_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.button14);
            this.groupBox6.Controls.Add(this.comboBox20);
            this.groupBox6.Controls.Add(this.comboBox21);
            this.groupBox6.Controls.Add(this.comboBox16);
            this.groupBox6.Controls.Add(this.comboBox17);
            this.groupBox6.Controls.Add(this.dateTimePicker10);
            this.groupBox6.Controls.Add(this.label149);
            this.groupBox6.Controls.Add(this.dateTimePicker5);
            this.groupBox6.Controls.Add(this.label91);
            this.groupBox6.Controls.Add(this.label92);
            this.groupBox6.Controls.Add(this.label93);
            this.groupBox6.Controls.Add(this.label94);
            this.groupBox6.Controls.Add(this.label95);
            this.groupBox6.Controls.Add(this.label48);
            this.groupBox6.Controls.Add(this.textBox121);
            this.groupBox6.Controls.Add(this.textBox21);
            this.groupBox6.Controls.Add(this.textBox11);
            this.groupBox6.Location = new System.Drawing.Point(674, 22);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(705, 315);
            this.groupBox6.TabIndex = 1;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Операции";
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(220, 194);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(141, 35);
            this.button14.TabIndex = 109;
            this.button14.Text = "Экспорт в Exel";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click_1);
            // 
            // comboBox20
            // 
            this.comboBox20.FormattingEnabled = true;
            this.comboBox20.Location = new System.Drawing.Point(264, 152);
            this.comboBox20.Name = "comboBox20";
            this.comboBox20.Size = new System.Drawing.Size(117, 24);
            this.comboBox20.TabIndex = 108;
            // 
            // comboBox21
            // 
            this.comboBox21.FormattingEnabled = true;
            this.comboBox21.Location = new System.Drawing.Point(220, 152);
            this.comboBox21.Name = "comboBox21";
            this.comboBox21.Size = new System.Drawing.Size(38, 24);
            this.comboBox21.TabIndex = 107;
            this.comboBox21.SelectedIndexChanged += new System.EventHandler(this.comboBox21_SelectedIndexChanged);
            // 
            // comboBox16
            // 
            this.comboBox16.FormattingEnabled = true;
            this.comboBox16.Location = new System.Drawing.Point(264, 39);
            this.comboBox16.Name = "comboBox16";
            this.comboBox16.Size = new System.Drawing.Size(117, 24);
            this.comboBox16.TabIndex = 104;
            // 
            // comboBox17
            // 
            this.comboBox17.FormattingEnabled = true;
            this.comboBox17.Location = new System.Drawing.Point(220, 39);
            this.comboBox17.Name = "comboBox17";
            this.comboBox17.Size = new System.Drawing.Size(38, 24);
            this.comboBox17.TabIndex = 103;
            this.comboBox17.SelectedIndexChanged += new System.EventHandler(this.comboBox17_SelectedIndexChanged);
            // 
            // dateTimePicker10
            // 
            this.dateTimePicker10.CustomFormat = "yyyy-MM-dd";
            this.dateTimePicker10.Location = new System.Drawing.Point(221, 68);
            this.dateTimePicker10.Name = "dateTimePicker10";
            this.dateTimePicker10.Size = new System.Drawing.Size(173, 22);
            this.dateTimePicker10.TabIndex = 100;
            this.dateTimePicker10.Value = new System.DateTime(2022, 3, 5, 0, 0, 0, 0);
            // 
            // label149
            // 
            this.label149.AutoSize = true;
            this.label149.Location = new System.Drawing.Point(101, 268);
            this.label149.Name = "label149";
            this.label149.Size = new System.Drawing.Size(114, 17);
            this.label149.TabIndex = 98;
            this.label149.Text = "Фильтр по дате";
            this.label149.UseWaitCursor = true;
            // 
            // dateTimePicker5
            // 
            this.dateTimePicker5.CustomFormat = "yyyy-MM-dd";
            this.dateTimePicker5.Location = new System.Drawing.Point(220, 263);
            this.dateTimePicker5.Name = "dateTimePicker5";
            this.dateTimePicker5.Size = new System.Drawing.Size(200, 22);
            this.dateTimePicker5.TabIndex = 97;
            this.dateTimePicker5.Value = new System.DateTime(2022, 3, 5, 0, 0, 0, 0);
            this.dateTimePicker5.ValueChanged += new System.EventHandler(this.dateTimePicker5_ValueChanged);
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Location = new System.Drawing.Point(106, 154);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(109, 17);
            this.label91.TabIndex = 93;
            this.label91.Text = "Номер занятия";
            this.label91.UseWaitCursor = true;
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Location = new System.Drawing.Point(149, 126);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(66, 17);
            this.label92.TabIndex = 92;
            this.label92.Text = "Причина";
            this.label92.UseWaitCursor = true;
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Location = new System.Drawing.Point(131, 96);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(84, 17);
            this.label93.TabIndex = 91;
            this.label93.Text = "Посещения";
            this.label93.UseWaitCursor = true;
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Location = new System.Drawing.Point(173, 72);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(42, 17);
            this.label94.TabIndex = 90;
            this.label94.Text = "Дата";
            this.label94.UseWaitCursor = true;
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Location = new System.Drawing.Point(106, 42);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(109, 17);
            this.label95.TabIndex = 89;
            this.label95.Text = "Номер ученика";
            this.label95.UseWaitCursor = true;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(25, 238);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(189, 17);
            this.label48.TabIndex = 80;
            this.label48.Text = "Фильтр по номеру ученика";
            this.label48.UseWaitCursor = true;
            // 
            // textBox121
            // 
            this.textBox121.Location = new System.Drawing.Point(220, 235);
            this.textBox121.Name = "textBox121";
            this.textBox121.Size = new System.Drawing.Size(100, 22);
            this.textBox121.TabIndex = 79;
            this.textBox121.TextChanged += new System.EventHandler(this.textBox121_TextChanged);
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(221, 95);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(100, 22);
            this.textBox21.TabIndex = 68;
            this.textBox21.UseWaitCursor = true;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(221, 123);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(100, 22);
            this.textBox11.TabIndex = 69;
            this.textBox11.UseWaitCursor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(519, 277);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(123, 43);
            this.button9.TabIndex = 77;
            this.button9.Text = "Редактировать";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.UseWaitCursor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click_1);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(403, 277);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(110, 43);
            this.button10.TabIndex = 76;
            this.button10.Text = "Удалить";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.UseWaitCursor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click_1);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(287, 277);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(110, 43);
            this.button12.TabIndex = 75;
            this.button12.Text = "Добавить";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.UseWaitCursor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click_1);
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(23, 277);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(110, 43);
            this.button26.TabIndex = 2;
            this.button26.Text = "Посещения";
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // dataGridView10
            // 
            this.dataGridView10.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView10.Location = new System.Drawing.Point(23, 22);
            this.dataGridView10.Name = "dataGridView10";
            this.dataGridView10.RowTemplate.Height = 24;
            this.dataGridView10.Size = new System.Drawing.Size(619, 240);
            this.dataGridView10.TabIndex = 1;
            this.dataGridView10.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView10_CellContentClick);
            this.dataGridView10.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView10_RowHeaderMouseClick);
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.tabControl1);
            this.tabPage8.Location = new System.Drawing.Point(4, 25);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(1599, 460);
            this.tabPage8.TabIndex = 1;
            this.tabPage8.Text = "Справочные таблицы";
            this.tabPage8.UseVisualStyleBackColor = true;
            this.tabPage8.Click += new System.EventHandler(this.tabPage8_Click);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.groupBox1);
            this.tabPage5.Controls.Add(this.button13);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(1599, 460);
            this.tabPage5.TabIndex = 2;
            this.tabPage5.Text = "Оформление договора";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dateTimePicker2);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.textBox115);
            this.groupBox1.Controls.Add(this.label38);
            this.groupBox1.Controls.Add(this.comboBox5);
            this.groupBox1.Controls.Add(this.comboBox4);
            this.groupBox1.Controls.Add(this.comboBox3);
            this.groupBox1.Controls.Add(this.dateTimePicker1);
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.label25);
            this.groupBox1.Controls.Add(this.label37);
            this.groupBox1.Controls.Add(this.textBox97);
            this.groupBox1.Controls.Add(this.label35);
            this.groupBox1.Controls.Add(this.textBox100);
            this.groupBox1.Controls.Add(this.label34);
            this.groupBox1.Controls.Add(this.textBox101);
            this.groupBox1.Controls.Add(this.label33);
            this.groupBox1.Controls.Add(this.textBox102);
            this.groupBox1.Controls.Add(this.label32);
            this.groupBox1.Controls.Add(this.textBox103);
            this.groupBox1.Controls.Add(this.label31);
            this.groupBox1.Controls.Add(this.label30);
            this.groupBox1.Controls.Add(this.label29);
            this.groupBox1.Controls.Add(this.label28);
            this.groupBox1.Controls.Add(this.textBox107);
            this.groupBox1.Location = new System.Drawing.Point(252, 14);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(882, 324);
            this.groupBox1.TabIndex = 32;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Договор";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(614, 115);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(191, 22);
            this.dateTimePicker2.TabIndex = 52;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(789, 87);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(36, 17);
            this.label4.TabIndex = 51;
            this.label4.Text = "BYN";
            // 
            // textBox115
            // 
            this.textBox115.Location = new System.Drawing.Point(266, 199);
            this.textBox115.Name = "textBox115";
            this.textBox115.Size = new System.Drawing.Size(115, 22);
            this.textBox115.TabIndex = 35;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(64, 202);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(198, 17);
            this.label38.TabIndex = 31;
            this.label38.Text = "Идентификационный номер ";
            // 
            // comboBox5
            // 
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Location = new System.Drawing.Point(739, 28);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(44, 24);
            this.comboBox5.TabIndex = 50;
            this.comboBox5.Visible = false;
            this.comboBox5.SelectedIndexChanged += new System.EventHandler(this.comboBox5_SelectedIndexChanged);
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(387, 168);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(36, 24);
            this.comboBox4.TabIndex = 49;
            this.comboBox4.Visible = false;
            this.comboBox4.SelectedIndexChanged += new System.EventHandler(this.comboBox4_SelectedIndexChanged);
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(614, 28);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(115, 24);
            this.comboBox3.TabIndex = 46;
            this.comboBox3.SelectedIndexChanged += new System.EventHandler(this.comboBox3_SelectedIndexChanged);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(614, 58);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(191, 22);
            this.dateTimePicker1.TabIndex = 44;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged_1);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(268, 168);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(113, 24);
            this.comboBox1.TabIndex = 42;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(147, 31);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(115, 17);
            this.label25.TabIndex = 18;
            this.label25.Text = "Номер договора";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(530, 115);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(78, 17);
            this.label37.TabIndex = 30;
            this.label37.Text = "Период до";
            // 
            // textBox97
            // 
            this.textBox97.Location = new System.Drawing.Point(268, 28);
            this.textBox97.Name = "textBox97";
            this.textBox97.Size = new System.Drawing.Size(113, 22);
            this.textBox97.TabIndex = 1;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(530, 87);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(78, 17);
            this.label35.TabIndex = 28;
            this.label35.Text = "Стоимость";
            // 
            // textBox100
            // 
            this.textBox100.Location = new System.Drawing.Point(268, 56);
            this.textBox100.Name = "textBox100";
            this.textBox100.Size = new System.Drawing.Size(113, 22);
            this.textBox100.TabIndex = 4;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(393, 61);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(215, 17);
            this.label34.TabIndex = 27;
            this.label34.Text = "Период обучения составляет с";
            // 
            // textBox101
            // 
            this.textBox101.Location = new System.Drawing.Point(268, 84);
            this.textBox101.Name = "textBox101";
            this.textBox101.Size = new System.Drawing.Size(113, 22);
            this.textBox101.TabIndex = 5;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(542, 31);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(66, 17);
            this.label33.TabIndex = 26;
            this.label33.Text = "Предмет";
            // 
            // textBox102
            // 
            this.textBox102.Location = new System.Drawing.Point(268, 112);
            this.textBox102.Name = "textBox102";
            this.textBox102.Size = new System.Drawing.Size(113, 22);
            this.textBox102.TabIndex = 6;
            this.textBox102.TextChanged += new System.EventHandler(this.textBox102_TextChanged);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(162, 171);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(100, 17);
            this.label32.TabIndex = 25;
            this.label32.Text = "ФИО ученика";
            // 
            // textBox103
            // 
            this.textBox103.Location = new System.Drawing.Point(268, 140);
            this.textBox103.Name = "textBox103";
            this.textBox103.Size = new System.Drawing.Size(113, 22);
            this.textBox103.TabIndex = 7;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(153, 59);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(109, 17);
            this.label31.TabIndex = 24;
            this.label31.Text = "ФИО родителя";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(214, 143);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(48, 17);
            this.label30.TabIndex = 23;
            this.label30.Text = "Адрес";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(145, 117);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(117, 17);
            this.label29.TabIndex = 22;
            this.label29.Text = "Номер паспорта";
            this.label29.Click += new System.EventHandler(this.label29_Click);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(147, 87);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(115, 17);
            this.label28.TabIndex = 21;
            this.label28.Text = "Серия паспорта";
            // 
            // textBox107
            // 
            this.textBox107.Location = new System.Drawing.Point(614, 84);
            this.textBox107.Name = "textBox107";
            this.textBox107.Size = new System.Drawing.Size(169, 22);
            this.textBox107.TabIndex = 11;
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(593, 344);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(113, 39);
            this.button13.TabIndex = 0;
            this.button13.Text = "Заполнение";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click_1);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.справкаToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1439, 28);
            this.menuStrip1.TabIndex = 33;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // справкаToolStripMenuItem
            // 
            this.справкаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.оПрограммеToolStripMenuItem,
            this.руководствоПользователяToolStripMenuItem});
            this.справкаToolStripMenuItem.Name = "справкаToolStripMenuItem";
            this.справкаToolStripMenuItem.Size = new System.Drawing.Size(79, 24);
            this.справкаToolStripMenuItem.Text = "Справка";
            // 
            // оПрограммеToolStripMenuItem
            // 
            this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
            this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(270, 26);
            this.оПрограммеToolStripMenuItem.Text = "О программе";
            this.оПрограммеToolStripMenuItem.Click += new System.EventHandler(this.оПрограммеToolStripMenuItem_Click);
            // 
            // руководствоПользователяToolStripMenuItem
            // 
            this.руководствоПользователяToolStripMenuItem.Name = "руководствоПользователяToolStripMenuItem";
            this.руководствоПользователяToolStripMenuItem.Size = new System.Drawing.Size(270, 26);
            this.руководствоПользователяToolStripMenuItem.Text = "Руководство пользователя";
            this.руководствоПользователяToolStripMenuItem.Click += new System.EventHandler(this.руководствоПользователяToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1439, 635);
            this.Controls.Add(this.tabControl2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "ПС \"Учет образовательных платных услуг в учреждении образования\"";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabPage4.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            this.tabControl4.ResumeLayout(false);
            this.tabPage11.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).EndInit();
            this.tabPage12.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView8)).EndInit();
            this.tabPage13.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView9)).EndInit();
            this.tabPage14.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView10)).EndInit();
            this.tabPage8.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.TextBox textBox48;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.TextBox textBox57;
        private System.Windows.Forms.TextBox textBox56;
        private System.Windows.Forms.TextBox textBox70;
        private System.Windows.Forms.TextBox textBox69;
        private System.Windows.Forms.TextBox textBox68;
        private System.Windows.Forms.TextBox textBox67;
        private System.Windows.Forms.TextBox textBox66;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.TabControl tabControl4;
        private System.Windows.Forms.TabPage tabPage11;
        private System.Windows.Forms.TabPage tabPage12;
        private System.Windows.Forms.TabPage tabPage13;
        private System.Windows.Forms.TabPage tabPage14;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.DataGridView dataGridView7;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.DataGridView dataGridView8;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.DataGridView dataGridView9;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.DataGridView dataGridView10;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox96;
        private System.Windows.Forms.TextBox textBox95;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TextBox textBox97;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox textBox107;
        private System.Windows.Forms.TextBox textBox103;
        private System.Windows.Forms.TextBox textBox102;
        private System.Windows.Forms.TextBox textBox101;
        private System.Windows.Forms.TextBox textBox100;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBox115;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBox118;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox textBox119;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox textBox120;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Label label122;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.Label label126;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label label138;
        private System.Windows.Forms.Label label139;
        private System.Windows.Forms.Label label140;
        private System.Windows.Forms.Label label141;
        private System.Windows.Forms.Label label142;
        private System.Windows.Forms.Label label143;
        private System.Windows.Forms.Label label144;
        private System.Windows.Forms.Label label145;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label147;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
        private System.Windows.Forms.DateTimePicker dateTimePicker4;
        private System.Windows.Forms.Label label148;
        private System.Windows.Forms.Label label149;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.DateTimePicker dateTimePicker6;
        private System.Windows.Forms.DateTimePicker dateTimePicker10;
        private System.Windows.Forms.DateTimePicker dateTimePicker13;
        private System.Windows.Forms.ComboBox comboBox8;
        private System.Windows.Forms.ComboBox comboBox9;
        private System.Windows.Forms.ComboBox comboBox12;
        private System.Windows.Forms.ComboBox comboBox13;
        private System.Windows.Forms.ComboBox comboBox16;
        private System.Windows.Forms.ComboBox comboBox17;
        private System.Windows.Forms.ComboBox comboBox20;
        private System.Windows.Forms.ComboBox comboBox21;
        private System.Windows.Forms.ComboBox comboBox24;
        private System.Windows.Forms.ComboBox comboBox25;
        private System.Windows.Forms.ComboBox comboBox28;
        private System.Windows.Forms.ComboBox comboBox29;
        private System.Windows.Forms.ComboBox comboBox32;
        private System.Windows.Forms.ComboBox comboBox33;
        private System.Windows.Forms.ComboBox comboBox38;
        private System.Windows.Forms.ComboBox comboBox39;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.ToolStripMenuItem справкаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem руководствоПользователяToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dateTimePicker5;
        private System.Windows.Forms.TextBox textBox121;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.DateTimePicker dateTimePicker8;
        private System.Windows.Forms.ComboBox comboBox37;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
    }
}

